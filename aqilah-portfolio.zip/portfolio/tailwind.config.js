/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ["var(--font-inter)", "sans-serif"], display: ["var(--font-jakarta)", "sans-serif"] },
      colors: { brand: { 500: "#6366f1", 600: "#4f46e5", 700: "#7c3aed" } },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-14px)" } },
        gradient: { "0%,100%": { backgroundPosition: "0% 50%" }, "50%": { backgroundPosition: "100% 50%" } },
      },
      animation: { float: "float 6s ease-in-out infinite", gradient: "gradient 8s ease infinite" },
    },
  },
  plugins: [],
};
