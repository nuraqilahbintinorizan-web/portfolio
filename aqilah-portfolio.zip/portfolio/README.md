# Nur Aqilah Norizan | Creative Explorer
Next.js 14 (App Router) · Tailwind CSS · Framer Motion · lucide-react

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```
Edit all content in `lib/data.js`. Replace picsum/pravatar placeholders with your own images (add hosts to `next.config.js` if remote).
