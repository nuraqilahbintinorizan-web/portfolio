import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const jakarta = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-jakarta" });

export const metadata = {
  title: "Nur Aqilah Norizan | Creative Explorer",
  description: "Turning Ideas into Beautiful Digital Experiences — the creative digital portfolio of Nur Aqilah Norizan.",
  keywords: ["portfolio", "web design", "UI/UX", "creative", "Nur Aqilah Norizan"],
  openGraph: {
    title: "Nur Aqilah Norizan | Creative Explorer",
    description: "Turning Ideas into Beautiful Digital Experiences",
    type: "website",
  },
};

const themeScript = `try{var t=localStorage.getItem('theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}`;

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body className={`${inter.variable} ${jakarta.variable} font-sans`}>{children}</body>
    </html>
  );
}
