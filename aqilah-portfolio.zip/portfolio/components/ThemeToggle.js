"use client";
import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);

  const toggle = () => {
    const next = !dark;
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("theme", next ? "dark" : "light"); } catch (e) {}
    setDark(next);
  };

  return (
    <button onClick={toggle} aria-label="Toggle dark mode" className="glass !rounded-full p-2.5 transition hover:scale-110">
      {dark ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
