"use client";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, Mail } from "lucide-react";
import { profile } from "@/lib/data";

export default function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden px-5 pb-16 pt-32 sm:px-8">
      <div className="pointer-events-none absolute -left-40 top-10 h-[28rem] w-[28rem] animate-float rounded-full bg-blue-500/30 blur-3xl" />
      <div className="pointer-events-none absolute -right-32 bottom-0 h-[30rem] w-[30rem] animate-float rounded-full bg-purple-600/30 blur-3xl [animation-delay:2s]" />

      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-14 lg:grid-cols-2">
        <motion.div initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} className="order-2 text-center lg:order-1 lg:text-left">
          <span className="glass inline-block !rounded-full px-4 py-1.5 text-sm font-medium">👋 Hello, I&apos;m</span>
          <h1 className="mt-6 font-display text-5xl font-extrabold leading-tight sm:text-6xl xl:text-7xl">
            <span className="gradient-text">{profile.name}</span>
          </h1>
          <p className="mt-5 font-display text-xl font-semibold sm:text-2xl">{profile.tagline}</p>
          <p className="mx-auto mt-4 max-w-xl text-slate-600 dark:text-slate-400 lg:mx-0">{profile.intro}</p>
          <div className="mt-9 flex flex-col items-center gap-4 sm:flex-row lg:justify-start sm:justify-center">
            <motion.a whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.96 }} href="#projects" className="btn-primary">
              Explore My Work <ArrowRight size={18} />
            </motion.a>
            <motion.a whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.96 }} href="#contact" className="btn-ghost">
              <Mail size={18} /> Contact Me
            </motion.a>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.9, delay: 0.2 }} className="order-1 mx-auto lg:order-2">
          <div className="relative animate-float">
            <div className="absolute -inset-3 animate-gradient rounded-[2.5rem] bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 bg-[length:200%_200%] opacity-70 blur-xl" />
            <div className="glass relative h-72 w-72 overflow-hidden !rounded-[2.5rem] p-2 sm:h-96 sm:w-96">
              <Image src="https://picsum.photos/seed/aqilah/800/800" alt="Portrait of Nur Aqilah Norizan" fill priority sizes="(max-width:640px) 18rem, 24rem" className="rounded-[2.2rem] object-cover" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
