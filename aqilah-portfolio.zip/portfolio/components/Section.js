import Reveal from "./Reveal";

export default function Section({ id, eyebrow, title, children }) {
  return (
    <section id={id} className="relative mx-auto max-w-7xl scroll-mt-20 px-5 py-24 sm:px-8">
      <Reveal className="mx-auto mb-14 max-w-2xl text-center">
        <span className="text-sm font-semibold uppercase tracking-[0.25em] text-indigo-500">{eyebrow}</span>
        <h2 className="mt-3 font-display text-4xl font-extrabold sm:text-5xl">{title}</h2>
        <div className="mx-auto mt-5 h-1 w-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600" />
      </Reveal>
      {children}
    </section>
  );
}
