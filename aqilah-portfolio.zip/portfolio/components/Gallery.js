"use client";
import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import Section from "./Section";
import { gallery } from "@/lib/data";

export default function Gallery() {
  const [active, setActive] = useState(null);
  return (
    <Section id="gallery" eyebrow="Moments" title="Gallery">
      <div className="columns-1 gap-4 space-y-4 sm:columns-2 lg:columns-3 xl:columns-4">
        {gallery.map((g, i) => (
          <motion.button
            key={g.src} onClick={() => setActive(g)}
            initial={{ opacity: 0, scale: 0.92 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            transition={{ delay: (i % 4) * 0.08 }} whileHover={{ scale: 1.02 }}
            className="group relative block w-full overflow-hidden rounded-3xl shadow-lg"
          >
            <Image src={g.src} alt={g.alt} width={700} height={800} className="h-auto w-full transition duration-700 group-hover:scale-110" />
            <span className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent opacity-0 transition group-hover:opacity-100" />
          </motion.button>
        ))}
      </div>
      <AnimatePresence>
        {active && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setActive(null)}
            className="fixed inset-0 z-[60] grid place-items-center bg-black/80 p-4 backdrop-blur-sm">
            <button className="absolute right-5 top-5 rounded-full bg-white/10 p-3 text-white" aria-label="Close"><X /></button>
            <Image src={active.src} alt={active.alt} width={900} height={900} className="max-h-[85vh] w-auto rounded-3xl object-contain" />
          </motion.div>
        )}
      </AnimatePresence>
    </Section>
  );
}
