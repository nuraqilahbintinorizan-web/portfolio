"use client";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import Section from "./Section";
import { projects } from "@/lib/data";

export default function Projects() {
  return (
    <Section id="projects" eyebrow="Selected Work" title="Featured Projects">
      <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
        {projects.map((p, i) => (
          <motion.article
            key={p.title}
            initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }}
            transition={{ delay: (i % 3) * 0.1, duration: 0.6 }} whileHover={{ y: -10 }}
            className="glass group overflow-hidden"
          >
            <div className="relative aspect-[10/7] overflow-hidden">
              <Image src={p.image} alt={p.title} fill sizes="(max-width:768px) 100vw, (max-width:1280px) 50vw, 33vw" className="object-cover transition duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-950/60 to-transparent opacity-0 transition group-hover:opacity-100" />
            </div>
            <div className="p-6">
              <h3 className="font-display text-xl font-bold">{p.title}</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{p.desc}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {p.tech.map((t) => <span key={t} className="rounded-full bg-indigo-500/10 px-3 py-1 text-xs font-medium text-indigo-600 dark:text-indigo-300">{t}</span>)}
              </div>
              <a href="#contact" className="btn-primary mt-6 !px-5 !py-2.5">View Details <ArrowUpRight size={16} /></a>
            </div>
          </motion.article>
        ))}
      </div>
    </Section>
  );
}
