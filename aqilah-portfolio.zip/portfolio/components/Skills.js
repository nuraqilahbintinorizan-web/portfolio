"use client";
import { motion } from "framer-motion";
import Section from "./Section";
import Icon from "./Icon";
import { skills } from "@/lib/data";

export default function Skills() {
  return (
    <Section id="skills" eyebrow="What I Do" title="My Skills">
      <div className="grid grid-cols-2 gap-4 sm:gap-6 md:grid-cols-3 lg:grid-cols-5">
        {skills.map((s, i) => (
          <motion.div
            key={s.name}
            initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ delay: i * 0.05 }} whileHover={{ y: -8, scale: 1.03 }}
            className="glass group flex flex-col items-center gap-4 p-6 text-center"
          >
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg shadow-indigo-500/30 transition group-hover:rotate-6">
              <Icon name={s.icon} className="h-7 w-7" />
            </span>
            <span className="text-sm font-semibold sm:text-base">{s.name}</span>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
