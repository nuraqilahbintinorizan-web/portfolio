"use client";
import { useState } from "react";
import { Mail, MapPin, Phone, Send } from "lucide-react";
import Section from "./Section";
import Reveal from "./Reveal";
import { profile } from "@/lib/data";

const field = "w-full rounded-2xl border border-slate-300/60 bg-white/70 px-4 py-3 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 dark:border-white/10 dark:bg-white/5";

export default function Contact() {
  const [sent, setSent] = useState(false);

  // Opens the visitor's email app. Swap for an API route / Formspree / Resend in production.
  const onSubmit = (e) => {
    e.preventDefault();
    const d = new FormData(e.currentTarget);
    const subject = encodeURIComponent(`Portfolio enquiry from ${d.get("name")}`);
    const body = encodeURIComponent(`${d.get("message")}\n\nFrom: ${d.get("name")} (${d.get("email")})`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  const info = [
    { Icon: Phone, label: "Phone", value: profile.phone, href: `tel:${profile.phone.replace(/-/g, "")}` },
    { Icon: Mail, label: "Email", value: profile.email, href: `mailto:${profile.email}` },
    { Icon: MapPin, label: "Location", value: profile.location },
  ];

  return (
    <Section id="contact" eyebrow="Get In Touch" title="Let's Work Together">
      <div className="grid gap-8 lg:grid-cols-5">
        <Reveal className="space-y-4 lg:col-span-2">
          {info.map(({ Icon, label, value, href }) => (
            <div key={label} className="glass flex items-center gap-4 p-5">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 text-white"><Icon size={20} /></span>
              <div className="min-w-0">
                <p className="text-sm text-slate-500">{label}</p>
                {href ? <a href={href} className="break-words font-semibold hover:text-indigo-500">{value}</a> : <p className="font-semibold">{value}</p>}
              </div>
            </div>
          ))}
        </Reveal>

        <Reveal delay={0.15} className="lg:col-span-3">
          <form onSubmit={onSubmit} className="glass space-y-4 p-6 sm:p-8">
            <div className="grid gap-4 sm:grid-cols-2">
              <input name="name" required placeholder="Your name" aria-label="Your name" className={field} />
              <input name="email" type="email" required placeholder="Your email" aria-label="Your email" className={field} />
            </div>
            <textarea name="message" required rows={5} placeholder="Tell me about your idea…" aria-label="Message" className={field} />
            <button type="submit" className="btn-primary w-full sm:w-auto">Send Message <Send size={16} /></button>
            {sent && <p className="text-sm text-emerald-500">Thanks! Your email app should open to send the message.</p>}
          </form>
        </Reveal>
      </div>
    </Section>
  );
}
