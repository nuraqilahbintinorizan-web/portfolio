import { GraduationCap, Sparkles, Heart } from "lucide-react";
import Section from "./Section";
import Reveal from "./Reveal";
import { education, funFacts, interests } from "@/lib/data";

export default function About() {
  return (
    <Section id="about" eyebrow="Who I Am" title="About Me">
      <div className="grid gap-6 lg:grid-cols-3">
        <Reveal className="glass p-8 lg:col-span-3">
          <p className="mx-auto max-w-3xl text-center text-lg leading-relaxed text-slate-600 dark:text-slate-300">
            I&apos;m a creative explorer who loves blending design, technology, and storytelling to craft
            digital experiences that feel effortless and look unforgettable. I&apos;m always curious, always
            learning, and always looking for the next idea worth building.
          </p>
        </Reveal>

        <Reveal delay={0.1} className="glass p-8">
          <Sparkles className="mb-4 text-purple-500" />
          <h3 className="mb-4 font-display text-xl font-bold">Fun Facts</h3>
          <ul className="space-y-3 text-slate-600 dark:text-slate-300">
            {funFacts.map((f) => <li key={f} className="flex gap-2"><span className="text-indigo-500">✦</span>{f}</li>)}
          </ul>
        </Reveal>

        <Reveal delay={0.2} className="glass p-8">
          <GraduationCap className="mb-4 text-blue-500" />
          <h3 className="mb-4 font-display text-xl font-bold">Education</h3>
          <ul className="space-y-4">
            {education.map((e) => (
              <li key={e.title} className="border-l-2 border-indigo-500/60 pl-4">
                <p className="font-semibold">{e.title}</p>
                <p className="text-sm text-slate-500">{e.place} · {e.year}</p>
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal delay={0.3} className="glass p-8">
          <Heart className="mb-4 text-pink-500" />
          <h3 className="mb-4 font-display text-xl font-bold">Interests</h3>
          <div className="flex flex-wrap gap-2">
            {interests.map((i) => (
              <span key={i} className="rounded-full bg-gradient-to-r from-blue-500/15 to-purple-500/15 px-4 py-2 text-sm font-medium transition hover:scale-105">{i}</span>
            ))}
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
