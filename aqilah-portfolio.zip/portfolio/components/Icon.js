import * as Lucide from "lucide-react";

export default function Icon({ name, className }) {
  const C = Lucide[name] || Lucide.Sparkles;
  return <C className={className} aria-hidden="true" />;
}
