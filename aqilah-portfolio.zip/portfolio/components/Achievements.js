"use client";
import { useEffect, useRef } from "react";
import { animate, useInView } from "framer-motion";
import Section from "./Section";
import Reveal from "./Reveal";
import { stats } from "@/lib/data";

function Counter({ to, suffix }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  useEffect(() => {
    if (!inView) return;
    const c = animate(0, to, { duration: 2, ease: "easeOut", onUpdate: (v) => { if (ref.current) ref.current.textContent = Math.round(v) + suffix; } });
    return () => c.stop();
  }, [inView, to, suffix]);
  return <span ref={ref}>0{suffix}</span>;
}

export default function Achievements() {
  return (
    <Section id="achievements" eyebrow="Milestones" title="Achievements">
      <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
        {stats.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.1} className="glass p-6 text-center sm:p-8">
            <p className="gradient-text font-display text-4xl font-extrabold sm:text-5xl"><Counter to={s.value} suffix={s.suffix} /></p>
            <p className="mt-3 text-sm font-medium text-slate-600 dark:text-slate-400 sm:text-base">{s.label}</p>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
