"use client";
import { ArrowUp } from "lucide-react";
import Icon from "./Icon";
import { profile, socials } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="relative border-t border-slate-200/70 px-5 py-12 dark:border-white/10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 sm:flex-row">
        <p className="text-sm text-slate-500">© {new Date().getFullYear()} {profile.name}. All rights reserved.</p>
        <div className="flex gap-3">
          {socials.map((s) => (
            <a key={s.name} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.name}
              className="glass grid h-11 w-11 place-items-center !rounded-full transition hover:-translate-y-1 hover:text-indigo-500">
              <Icon name={s.icon} className="h-5 w-5" />
            </a>
          ))}
        </div>
        <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="btn-primary !px-5 !py-2.5">
          Back to top <ArrowUp size={16} />
        </button>
      </div>
    </footer>
  );
}
