import Image from "next/image";
import { Quote, Star } from "lucide-react";
import Section from "./Section";
import Reveal from "./Reveal";
import { testimonials } from "@/lib/data";

export default function Testimonials() {
  return (
    <Section id="testimonials" eyebrow="Kind Words" title="Testimonials">
      <div className="grid gap-6 md:grid-cols-3">
        {testimonials.map((t, i) => (
          <Reveal key={t.name} delay={i * 0.12} className="glass relative p-8 transition hover:-translate-y-2">
            <Quote className="absolute right-6 top-6 h-8 w-8 text-indigo-500/30" />
            <div className="mb-4 flex gap-1 text-amber-400">{[...Array(5)].map((_, n) => <Star key={n} size={16} fill="currentColor" />)}</div>
            <p className="text-slate-600 dark:text-slate-300">&ldquo;{t.text}&rdquo;</p>
            <div className="mt-6 flex items-center gap-4">
              <Image src={t.img} alt={t.name} width={52} height={52} className="rounded-full ring-2 ring-indigo-500/50" />
              <div><p className="font-semibold">{t.name}</p><p className="text-sm text-slate-500">{t.role}</p></div>
            </div>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
